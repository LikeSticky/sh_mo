import setBreakpoint from './setBreakpoint.js';
import getBreakpoint from './getBreakpoint.js';

export default { setBreakpoint, getBreakpoint };
